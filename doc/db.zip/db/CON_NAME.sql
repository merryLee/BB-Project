--------------------------------------------------------
--  ������ ������ - ������-10��-30-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CON_NAME
--------------------------------------------------------

  CREATE TABLE "BBA"."CON_NAME" 
   (	"CNO" NUMBER, 
	"CNAME" VARCHAR2(20 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "BBA"."CON_NAME"."CNO" IS '�ü���ȣ';
   COMMENT ON COLUMN "BBA"."CON_NAME"."CNAME" IS '�ü��̸�';
   COMMENT ON TABLE "BBA"."CON_NAME"  IS '���ǽü�';
REM INSERTING into BBA.CON_NAME
SET DEFINE OFF;
Insert into BBA.CON_NAME (CNO,CNAME) values (1,'Wi-Fi');
Insert into BBA.CON_NAME (CNO,CNAME) values (2,'������');
Insert into BBA.CON_NAME (CNO,CNAME) values (3,'��Ź��');
Insert into BBA.CON_NAME (CNO,CNAME) values (4,'�ٸ���');
Insert into BBA.CON_NAME (CNO,CNAME) values (5,'������');
Insert into BBA.CON_NAME (CNO,CNAME) values (6,'��ǿ�ǰ');
Insert into BBA.CON_NAME (CNO,CNAME) values (7,'������̾�');
Insert into BBA.CON_NAME (CNO,CNAME) values (8,'TV');
Insert into BBA.CON_NAME (CNO,CNAME) values (9,'�ݷ�����');
Insert into BBA.CON_NAME (CNO,CNAME) values (10,'����������');
Insert into BBA.CON_NAME (CNO,CNAME) values (11,'��������');
Insert into BBA.CON_NAME (CNO,CNAME) values (12,'24�ð�����Ʈ');
--------------------------------------------------------
--  DDL for Index PK_CON_NAME
--------------------------------------------------------

  CREATE UNIQUE INDEX "BBA"."PK_CON_NAME" ON "BBA"."CON_NAME" ("CNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table CON_NAME
--------------------------------------------------------

  ALTER TABLE "BBA"."CON_NAME" ADD CONSTRAINT "PK_CON_NAME" PRIMARY KEY ("CNO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "BBA"."CON_NAME" MODIFY ("CNO" NOT NULL ENABLE);
