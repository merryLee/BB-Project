--------------------------------------------------------
--  ������ ������ - ������-10��-30-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table HOUSE_IMG
--------------------------------------------------------

  CREATE TABLE "BBA"."HOUSE_IMG" 
   (	"HNO" NUMBER(10,0), 
	"THUMB1" VARCHAR2(100 BYTE), 
	"THUMB2" VARCHAR2(100 BYTE), 
	"THUMB3" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;

   COMMENT ON COLUMN "BBA"."HOUSE_IMG"."HNO" IS '���ҹ�ȣ';
   COMMENT ON COLUMN "BBA"."HOUSE_IMG"."THUMB1" IS '�����1';
   COMMENT ON COLUMN "BBA"."HOUSE_IMG"."THUMB2" IS '�����2';
   COMMENT ON COLUMN "BBA"."HOUSE_IMG"."THUMB3" IS '�����3';
   COMMENT ON TABLE "BBA"."HOUSE_IMG"  IS '�����̹���';
REM INSERTING into BBA.HOUSE_IMG
SET DEFINE OFF;
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10026,'.\\img\\house6.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10024,'.\\img\\house6.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10025,'.\\img\\house6.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10001,'.\\img\\house1.png','C:\Users\jungseungho\Desktop\1��������Ʈ\img\house6.png','null');
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10002,'.\\img\\house2.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10003,'.\\img\\house3.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10004,'.\\img\\house4.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10005,'.\\img\\house5.png',null,null);
Insert into BBA.HOUSE_IMG (HNO,THUMB1,THUMB2,THUMB3) values (10006,'.\\img\\house6.png',null,null);
--------------------------------------------------------
--  DDL for Index PK_HOUSE_IMG
--------------------------------------------------------

  CREATE UNIQUE INDEX "BBA"."PK_HOUSE_IMG" ON "BBA"."HOUSE_IMG" ("HNO") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS" ;
--------------------------------------------------------
--  Constraints for Table HOUSE_IMG
--------------------------------------------------------

  ALTER TABLE "BBA"."HOUSE_IMG" ADD CONSTRAINT "PK_HOUSE_IMG" PRIMARY KEY ("HNO")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "USERS"  ENABLE;
  ALTER TABLE "BBA"."HOUSE_IMG" MODIFY ("THUMB1" NOT NULL ENABLE);
  ALTER TABLE "BBA"."HOUSE_IMG" MODIFY ("HNO" NOT NULL ENABLE);
