package bb_final;

import javax.swing.JPanel;

public class Top extends JPanel {

	/**
	 * Create the panel.
	 */
	public Top() {

	}

}
