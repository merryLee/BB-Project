package com.bb.common;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.bb.common.model.SwingCalendarLogic;

public class SwingCalendar extends JFrame {
	private JPanel contentPane;

	public DefaultTableModel model;
	public Calendar cal = new GregorianCalendar();
	public JLabel label;
	public JTextField extField;
	public int month;
	public int year;
	public JTable table;

	JButton b1 = new JButton("<");
	JButton b2 = new JButton(">");
	JPanel panel = new JPanel();
	public SwingCalendar() {
		
		setTitle("Calendar");
		setDefaultCloseOperation(SwingCalendar.EXIT_ON_CLOSE);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		contentPane.setLayout(new BorderLayout(0, 0));
		

		setContentPane(contentPane);


		label = new JLabel();
		label.setHorizontalAlignment(SwingConstants.CENTER);


		panel.setLayout(new BorderLayout());
		panel.setBorder(new EmptyBorder(10, 0, 10, 0));
		panel.add(b1, BorderLayout.WEST);
		panel.add(label, BorderLayout.CENTER);
		panel.add(b2, BorderLayout.EAST);

		String[] columns = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
		model = new DefaultTableModel(null, columns) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		table = new JTable(model);
		table.setBorder(null);

		table.getTableHeader().setReorderingAllowed(false);

		table.setCellSelectionEnabled(true);
		JScrollPane pane = new JScrollPane(table);
		pane.setBackground(Color.GREEN);
		pane.setBorder(new EmptyBorder(0, 0, 0, 0));
		
		//getContentPane().add(panel, BorderLayout.NOR TH);
		getContentPane().add(pane, BorderLayout.CENTER);

		SwingCalendarLogic scl = new SwingCalendarLogic(this);
		updateMonth();
//		scl.updateMonth();


		System.out.println(table.getColumnCount() + " " + table.getY());
		System.out.println(table.getHeight());
		table.setRowHeight(20);
		

		setBounds(100, 100, 360, 260);
		setVisible(false);
		
		
//		��Ϻ�
				
//		�̺�Ʈ ���
		table.addMouseListener(scl);		
		b1.addActionListener(scl);
		b2.addActionListener(scl);

	}

	public void updateMonth() {
		cal.set(Calendar.DAY_OF_MONTH, 1);
		
		month = cal.get(Calendar.MONTH);
		year = cal.get(Calendar.YEAR);
		label.setText(year + ". " + month + ". ");
		
		int startDay = cal.get(Calendar.DAY_OF_WEEK);
		int numberOfDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		int weeks = cal.getActualMaximum(Calendar.WEEK_OF_MONTH);
		
		model.setRowCount(0);
		model.setRowCount(weeks);
		
		int i = startDay - 1;
		for (int day = 1; day <= numberOfDays; day++) {
			model.setValueAt(day, i / 7, i % 7);
			i = i + 1;
		}
	}
}