package com.bb.common.model;

import java.awt.event.*;
import java.util.Calendar;

import javax.swing.JTable;

import com.bb.common.SwingCalendar;

public class SwingCalendarLogic implements ActionListener, MouseListener {

	SwingCalendar sc;
	
	
	public SwingCalendarLogic(SwingCalendar sc) {
		this.sc = sc;	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		String key = e.getActionCommand();
		
		if ("<".equals(key)) {	//b1
			sc.cal.add(Calendar.MONTH, -1);
			sc.updateMonth();		
		}
		if (">".equals(key)) {	//b1
			sc.cal.add(Calendar.MONTH, +1);
			sc.updateMonth();	
		}
		
		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
//table
		JTable target = (JTable) e.getSource();
		int row = target.getSelectedRow();
		int column = target.getSelectedColumn();
		
		if (e.getButton() == 1) {
			if (e.getClickCount() == 2) {
				System.out.println("�ι�Ŭ�� = " + row + " " + column);
				sc.extField.setText(sc.year + ". " + sc.month + ". " + target.getValueAt(row, column) + "");
				
				sc.setVisible(false);
				
			} else {
				System.out.println(target.getValueAt(row, column));
				
				System.out.println("�ѹ�Ŭ�� = " + row + " " + column);
			}
		}
		
	}

	
	
//	public void updateMonth() {
//		sc.cal.set(Calendar.DAY_OF_MONTH, 1);
//		
//		sc.month = sc.cal.get(Calendar.MONTH);
//		sc.year = sc.cal.get(Calendar.YEAR);
//		sc.label.setText(sc.year + ". " + sc.month + ". ");
//		
//		int startDay = sc.cal.get(Calendar.DAY_OF_WEEK);
//		int numberOfDays = sc.cal.getActualMaximum(Calendar.DAY_OF_MONTH);
//		int weeks = sc.cal.getActualMaximum(Calendar.WEEK_OF_MONTH);
//		
//		sc.model.setRowCount(0);
//		sc.model.setRowCount(weeks);
//		
//		int i = startDay - 1;
//		for (int day = 1; day <= numberOfDays; day++) {
//			sc.model.setValueAt(day, i / 7, i % 7);
//			i = i + 1;
//		}
//	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
