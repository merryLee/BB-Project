package com.bb.home.model;

public class HomeLogic {

}
