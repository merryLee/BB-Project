package com.bb.home.model;

public class SearchLogic {

}
