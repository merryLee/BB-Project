package com.bb.review.model;

public class ReviewDto {

	private int rno;
	private int bno;
	private int rscore1;
	private int rscore2;
	private int rscore3;
	private int rscore4;
	private String rspec;
	private String rdate;
	private int rcnt;
	
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getRscore1() {
		return rscore1;
	}
	public void setRscore1(int rscore1) {
		this.rscore1 = rscore1;
	}
	public int getRscore2() {
		return rscore2;
	}
	public void setRscore2(int rscore2) {
		this.rscore2 = rscore2;
	}
	public int getRscore3() {
		return rscore3;
	}
	public void setRscore3(int rscore3) {
		this.rscore3 = rscore3;
	}
	public int getRscore4() {
		return rscore4;
	}
	public void setRscore4(int rscore4) {
		this.rscore4 = rscore4;
	}
	public String getRspec() {
		return rspec;
	}
	public void setRspec(String rspec) {
		this.rspec = rspec;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public int getRcnt() {
		return rcnt;
	}
	public void setRcnt(int rcnt) {
		this.rcnt = rcnt;
	}
	
	
}
